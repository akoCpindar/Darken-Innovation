<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="5;url=../system/logout.php">
        <title>Redirection</title>
    </head>
    <body style="font-family: arial; font-size: 12px; margin-top:50px; text-align: center;">
		Thank you for voting! You will be logout after 5 seconds...<br>
        <!-- Note: don't tell people to `click` the link, just tell them that it is a link. -->
        If you are not redirected automatically, Click the <a href='../system/logout.php'>link</a>
    </body>
</html>